package algorithm;

public class Pair2 {

	private Nodo first;
	private int second;

	public Pair2(Nodo _first, int _second) {
		first = _first;
		second = _second;
	}

	public Nodo getFirst() {
		return first;
	}

	public void setFirst(Nodo first) {
		this.first = first;
	}

	public int getSecond() {
		return second;
	}

	public void setSecond(int second) {
		this.second = second;
	}

}
