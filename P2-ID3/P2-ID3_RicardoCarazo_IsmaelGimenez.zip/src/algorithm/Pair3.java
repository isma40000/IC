package algorithm;

public class Pair3 {

	private String first;
	private int second;

	public Pair3(String _first, int _second) {
		first = _first;
		second = _second;
	}

	public String getFirst() {
		return first;
	}

	public void setFirst(String first) {
		this.first = first;
	}

	public int getSecond() {
		return second;
	}

	public void setSecond(int second) {
		this.second = second;
	}

}
