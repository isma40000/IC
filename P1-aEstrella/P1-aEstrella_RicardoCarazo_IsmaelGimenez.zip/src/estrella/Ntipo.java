package estrella;

public enum Ntipo {
	NORMAL, INICIO, META, PROHIBIDO, WAYPOINT, SOLUCION;
}
